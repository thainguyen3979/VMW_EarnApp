﻿from __future__ import annotations

import ctypes
import json
import os
import shutil
import subprocess
import tempfile
import threading
import time
import tkinter as tk
import urllib.error
import urllib.request
import zipfile
from collections.abc import Callable
from ctypes import wintypes
from dataclasses import asdict, dataclass, field, replace
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText
from typing import Literal

# Theme

BG = "#1e1e2e"
BG2 = "#181825"
PANEL = "#11111b"
FG = "#cdd6f4"
DIM = "#6c7086"
ACC = "#89b4fa"
ACC2 = "#74c7ec"
OK = "#a6e3a1"
ERR = "#f38ba8"
WARN = "#fab387"
INFO = "#89dceb"
BORDER = "#313244"

FONT_UI = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_HEAD = ("Segoe UI Semibold", 16)
FONT_MONO = ("Consolas", 10)

# Shared Models

from dataclasses import dataclass


@dataclass(slots=True)
class VmInfo:
    name: str
    state: str
    memory_mb: int = 0
    details: str = ""
    uuid: str = ""


@dataclass(slots=True)
class ProxyEntry:
    proxy_type: str
    host: str
    port: int
    username: str = ""
    password: str = ""
    raw: str = ""


@dataclass(slots=True)
class NodeStatus:
    node_number: int
    user_name: str
    box_name: str
    running: bool = False
    details: str = ""

# Shared Utils

import os
import subprocess


def creation_flags() -> int:
    return subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


def run_command(args: list[str], cwd: str | None = None, timeout: int | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        args,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=timeout,
        creationflags=creation_flags(),
    )

# Shared Widgets

import tkinter as tk
from tkinter import filedialog, ttk
from tkinter.scrolledtext import ScrolledText



def make_scrolled_left_panel(parent: tk.Misc, width: int = 340) -> tuple[tk.Canvas, ttk.Frame]:
    outer = ttk.Frame(parent)
    outer.pack(fill="both", expand=True)

    canvas = tk.Canvas(outer, bg=BG, bd=0, highlightthickness=0, width=width)
    scrollbar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
    content = ttk.Frame(canvas)

    content.bind(
        "<Configure>",
        lambda _e: canvas.configure(scrollregion=canvas.bbox("all")),
    )
    canvas.bind(
        "<Configure>",
        lambda e: canvas.itemconfigure(window_id, width=e.width),
    )

    window_id = canvas.create_window((0, 0), window=content, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")
    return canvas, content


def browse_file(var: tk.StringVar, filetypes: list[tuple[str, str]] | None = None) -> None:
    path = filedialog.askopenfilename(filetypes=filetypes or [("All files", "*.*")])
    if path:
        var.set(path)


def browse_dir(var: tk.StringVar) -> None:
    path = filedialog.askdirectory()
    if path:
        var.set(path)


def add_labeled_row(group: ttk.Frame, label: str, var: tk.Variable, numeric: bool = False, width: int = 14) -> ttk.Entry:
    row = ttk.Frame(group)
    row.pack(fill="x", pady=4)
    ttk.Label(row, text=label, width=18).pack(side="left")
    entry = ttk.Entry(row, textvariable=var, width=width)
    entry.pack(side="left", fill="x", expand=True)
    if numeric:
        entry.configure(justify="center")
    return entry


def add_hint(parent: ttk.Frame, text: str) -> None:
    ttk.Label(parent, text=text, style="Dim.TLabel", wraplength=280, justify="left").pack(fill="x", pady=(2, 6))


def build_log_widget(parent: tk.Misc) -> ScrolledText:
    widget = ScrolledText(
        parent,
        bg=PANEL,
        fg=FG,
        insertbackground=FG,
        relief="flat",
        borderwidth=0,
        font=FONT_MONO,
        wrap="word",
    )
    widget.pack(fill="both", expand=True)
    return widget

# Config

from dataclasses import dataclass, replace
from pathlib import Path


@dataclass(slots=True)
class GuestToolConfig:
    user_prefix: str = "Dylan"
    node_count: int = 6
    sandboxie_root: str = r"C:\App\Sandboxie\Sandboxie_Base\Sandboxie-Plus"
    earnapp_root: str = r"C:\App\EarnApp"
    proxifier_profile_dir: str = r"C:\Users\Admin\AppData\Roaming\Proxifier4\Profiles"
    admin_password: str = "Admin@123"
    proxifier_sync_source: str = r"C:\Proxy"
    github_version_url: str = ""
    github_release_api: str = ""
    github_asset_name: str = ""
    task_manager_command: tuple[str, ...] = ("taskmgr.exe",)
    session_state_path: str = str(Path.cwd() / "guest_tool_session.json")

    def with_seed_payload(self, payload: dict) -> "GuestToolConfig":
        sandboxie_root = str(payload.get("sandboxie_root", self.sandboxie_root))
        if sandboxie_root.rstrip("\\").endswith(r"Sandboxie_Base\Sandboxie-Plus"):
            normalized_sandboxie_root = sandboxie_root
        elif sandboxie_root.rstrip("\\").endswith("Sandboxie"):
            normalized_sandboxie_root = sandboxie_root.rstrip("\\") + r"\Sandboxie_Base\Sandboxie-Plus"
        else:
            normalized_sandboxie_root = sandboxie_root

        return replace(
            self,
            user_prefix=str(payload.get("user_prefix", self.user_prefix)),
            node_count=int(payload.get("node_count", self.node_count)),
            sandboxie_root=normalized_sandboxie_root,
            earnapp_root=str(payload.get("earnapp_root", self.earnapp_root)),
            proxifier_profile_dir=str(payload.get("proxy_profile_root", self.proxifier_profile_dir)),
        )

# Guest Models

from dataclasses import asdict, dataclass, field
from typing import Literal



@dataclass(slots=True)
class NodeTarget:
    raw: str
    nodes: list[int]
    kind: Literal["single", "range"]

    @property
    def first_node(self) -> int:
        return self.nodes[0]

    @property
    def last_node(self) -> int:
        return self.nodes[-1]

    @property
    def single_node(self) -> int:
        if self.kind != "single":
            raise ValueError("Node target is not a single node")
        return self.nodes[0]


@dataclass(slots=True)
class ProxyAssignment:
    node_number: int
    user_name: str
    proxy: ProxyEntry
    proxy_name: str = ""

    def resolved_proxy_name(self) -> str:
        return self.proxy_name or f"Proxy {self.node_number}"


@dataclass(slots=True)
class NodeRuntimeState:
    node_number: int
    user_name: str
    box_name: str
    earnapp_path: str
    start_pid: int | None = None
    sandman_pid: int | None = None
    earnapp_hidden: bool = False
    sandman_hidden: bool = False
    last_verify_ok: bool | None = None
    last_action: str = "idle"

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict) -> "NodeRuntimeState":
        return cls(
            node_number=int(payload.get("node_number", 0)),
            user_name=str(payload.get("user_name", "")),
            box_name=str(payload.get("box_name", "")),
            earnapp_path=str(payload.get("earnapp_path", "")),
            start_pid=_to_optional_int(payload.get("start_pid")),
            sandman_pid=_to_optional_int(payload.get("sandman_pid")),
            earnapp_hidden=bool(payload.get("earnapp_hidden", False)),
            sandman_hidden=bool(payload.get("sandman_hidden", False)),
            last_verify_ok=_to_optional_bool(payload.get("last_verify_ok")),
            last_action=str(payload.get("last_action", "idle")),
        )


@dataclass(slots=True)
class GuestPanelSession:
    node_index: str = "1"
    interval_seconds: str = "5"
    auto_hide: bool = True
    sandman_hide: bool = True
    last_proxy_sync: str = ""
    last_update_sync: str = ""
    last_update_version: str = ""
    runtime_states: dict[int, NodeRuntimeState] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "node_index": self.node_index,
            "interval_seconds": self.interval_seconds,
            "auto_hide": self.auto_hide,
            "sandman_hide": self.sandman_hide,
            "last_proxy_sync": self.last_proxy_sync,
            "last_update_sync": self.last_update_sync,
            "last_update_version": self.last_update_version,
            "runtime_states": [state.to_dict() for state in sorted(self.runtime_states.values(), key=lambda item: item.node_number)],
        }

    @classmethod
    def from_dict(cls, payload: dict) -> "GuestPanelSession":
        runtime_states: dict[int, NodeRuntimeState] = {}
        for item in payload.get("runtime_states", []):
            state = NodeRuntimeState.from_dict(item)
            if state.node_number > 0:
                runtime_states[state.node_number] = state
        return cls(
            node_index=str(payload.get("node_index", "1")),
            interval_seconds=str(payload.get("interval_seconds", "5")),
            auto_hide=bool(payload.get("auto_hide", True)),
            sandman_hide=bool(payload.get("sandman_hide", True)),
            last_proxy_sync=str(payload.get("last_proxy_sync", "")),
            last_update_sync=str(payload.get("last_update_sync", "")),
            last_update_version=str(payload.get("last_update_version", "")),
            runtime_states=runtime_states,
        )


def _to_optional_int(value) -> int | None:
    if value in (None, ""):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None



def _to_optional_bool(value) -> bool | None:
    if value is None:
        return None
    return bool(value)

# Services: Sandboxie

import os
import subprocess
from pathlib import Path



class SandboxieService:
    def __init__(self, base_dir: str) -> None:
        self.base_dir = base_dir
        self.start_exe = str(Path(base_dir) / "Start.exe")
        self.sandman_exe = str(Path(base_dir) / "SandMan.exe")
        self.sbieini_exe = str(Path(base_dir) / "SbieIni.exe")
        self.active_ini = str(Path(base_dir) / "Sandboxie.ini")
        self.kmdutil_exe = str(Path(base_dir) / "KmdUtil.exe")
        self.sbiesvc_exe = str(Path(base_dir) / "SbieSvc.exe")
        self.sbiedrv_sys = str(Path(base_dir) / "SbieDrv.sys")
        self.sbiemsg_dll = str(Path(base_dir) / "SbieMsg.dll")

    def box_name(self, user_name: str) -> str:
        safe = "".join(ch for ch in user_name if ch.isalnum())
        box = f"Box{safe}" if safe else "Box1"
        return box[:32]

    def ensure_runtime_ready(self) -> list[str]:
        missing = [p for p in [self.start_exe, self.sandman_exe, self.sbieini_exe] if not os.path.exists(p)]
        if missing:
            raise RuntimeError(f"Missing Sandboxie runtime file(s): {', '.join(missing)}")
        return [
            f">> BaseDir      = {self.base_dir}",
            f">> StartExe     = {self.start_exe}",
            f">> SandManExe   = {self.sandman_exe}",
            f">> SbieIniExe   = {self.sbieini_exe}",
            f">> ActiveIni    = {self.active_ini}",
        ]

    def ensure_core_services(self) -> list[str]:
        script = r'''
$ErrorActionPreference = "Stop"
$KmdUtil = "__KMDUTIL__"
$SbieSvcExe = "__SBIESVC__"
$SbieDrvSys = "__SBIEDRV__"
$SbieMsgDll = "__SBIEMSG__"
$SbieIniExe = "__SBIEINI__"

foreach ($p in @($KmdUtil, $SbieSvcExe, $SbieDrvSys, $SbieMsgDll, $SbieIniExe)) {
    if (-not (Test-Path $p)) {
        throw "Missing Sandboxie core file: $p"
    }
}

if (-not (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Services\SbieDrv")) {
    & $KmdUtil install SbieDrv $SbieDrvSys 'type=kernel' 'start=demand' "msgfile=$SbieMsgDll" 'altitude=86900'
    if ($LASTEXITCODE -ne 0) {
        throw "Install SbieDrv failed: $LASTEXITCODE"
    }
}

if (-not (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Services\SbieSvc")) {
    & $KmdUtil install SbieSvc $SbieSvcExe 'type=own' 'start=auto' 'display=Sandboxie Service' 'group=UIGroup' "msgfile=$SbieMsgDll"
    if ($LASTEXITCODE -ne 0) {
        throw "Install SbieSvc failed: $LASTEXITCODE"
    }
}

$SvcImagePath = $SbieSvcExe
$DrvImagePath = '\??\' + $SbieDrvSys
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\SbieSvc" -Name "ImagePath" -Value $SvcImagePath -PropertyType ExpandString -Force | Out-Null
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\SbieDrv" -Name "ImagePath" -Value $DrvImagePath -PropertyType ExpandString -Force | Out-Null

$drvQuery = sc.exe query SbieDrv | Out-String
if ($drvQuery -notmatch "STATE\s*:\s*4\s+RUNNING") {
    sc.exe start SbieDrv | Out-Null
}

$svcQuery = sc.exe query SbieSvc | Out-String
if ($svcQuery -notmatch "STATE\s*:\s*4\s+RUNNING") {
    Start-Service -Name "SbieSvc" -ErrorAction SilentlyContinue
}

for ($i = 0; $i -lt 20; $i++) {
    $drvQuery = sc.exe query SbieDrv | Out-String
    $svcQuery = sc.exe query SbieSvc | Out-String
    if (($drvQuery -match "STATE\s*:\s*4\s+RUNNING") -and ($svcQuery -match "STATE\s*:\s*4\s+RUNNING")) {
        break
    }
    Start-Sleep -Milliseconds 500
}

if ($drvQuery -notmatch "STATE\s*:\s*4\s+RUNNING") {
    throw "SbieDrv is not running"
}
if ($svcQuery -notmatch "STATE\s*:\s*4\s+RUNNING") {
    throw "SbieSvc is not running"
}

& $SbieIniExe set /drv DefaultBox Enabled y | Out-Null
& $SbieIniExe set /drv DefaultBox BlockNetworkFiles y | Out-Null

Write-Host ">> ---- SbieDrv query ----"
foreach ($line in ($drvQuery -split "`r?`n")) {
    if ($line) { Write-Host ">> $line" }
}
Write-Host ">> ---- SbieSvc query ----"
foreach ($line in ($svcQuery -split "`r?`n")) {
    if ($line) { Write-Host ">> $line" }
}
Write-Host ">> DefaultBox ensured"
'''
        script = (
            script.replace("__KMDUTIL__", self.kmdutil_exe)
            .replace("__SBIESVC__", self.sbiesvc_exe)
            .replace("__SBIEDRV__", self.sbiedrv_sys)
            .replace("__SBIEMSG__", self.sbiemsg_dll)
            .replace("__SBIEINI__", self.sbieini_exe)
        )
        return self._run_script(script)

    def create_box(self, user_name: str, box_name: str) -> list[str]:
        script = r'''
$ErrorActionPreference = "Stop"
$SbieIniExe = "__SBIEINI__"
$StartExe = "__START__"
$BoxName = "__BOX__"

& $SbieIniExe set /drv $BoxName Enabled y | Out-Null
if ($LASTEXITCODE -ne 0) { throw "Failed to create box (Enabled)" }
& $SbieIniExe set /drv $BoxName FileRootPath 'C:\Sandbox\%USER%\%SANDBOX%' | Out-Null
if ($LASTEXITCODE -ne 0) { throw "Failed to create box (FileRootPath)" }
& $SbieIniExe set /drv $BoxName AutoRecover n | Out-Null
& $SbieIniExe set /drv $BoxName DropAdminRights y | Out-Null
& $SbieIniExe set /drv $BoxName BlockNetworkFiles y | Out-Null
Start-Process -FilePath $StartExe -ArgumentList "/reload" -Wait -WindowStyle Hidden
Start-Sleep -Milliseconds 500
Write-Host ">> UserName     = __USER__"
Write-Host ">> BoxName      = $BoxName"
Write-Host ">> FileRootPath = C:\Sandbox\%USER%\%SANDBOX%"
'''
        script = (
            script.replace("__SBIEINI__", self.sbieini_exe)
            .replace("__START__", self.start_exe)
            .replace("__BOX__", box_name)
            .replace("__USER__", user_name)
        )
        return self._run_script(script)

    def delete_box(self, user_name: str, box_name: str) -> list[str]:
        script = r'''
$ErrorActionPreference = "Stop"
$SbieIniExe = "__SBIEINI__"
$StartExe = "__START__"
$UserName = "__USER__"
$BoxName = "__BOX__"
$BoxPath = "C:\Sandbox\$UserName\$BoxName"

Start-Process -FilePath $StartExe -ArgumentList "/box:$BoxName /terminate" -Wait -WindowStyle Hidden -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 500
Start-Process -FilePath $StartExe -ArgumentList "/box:$BoxName delete_sandbox_silent" -Wait -WindowStyle Hidden -ErrorAction SilentlyContinue
if (Test-Path $BoxPath) {
    Remove-Item -Path $BoxPath -Recurse -Force -ErrorAction SilentlyContinue
}
& $SbieIniExe set /drv $BoxName * "" | Out-Null
Start-Process -FilePath $StartExe -ArgumentList "/reload" -Wait -WindowStyle Hidden -ErrorAction SilentlyContinue
Write-Host ">> Removed box section: $BoxName"
Write-Host ">> Removed sandbox path: $BoxPath"
'''
        script = (
            script.replace("__SBIEINI__", self.sbieini_exe)
            .replace("__START__", self.start_exe)
            .replace("__USER__", user_name)
            .replace("__BOX__", box_name)
        )
        return self._run_script(script)

    def list_boxes(self) -> list[str]:
        script = rf'& "{self.sbieini_exe}" queryex /boxes *'
        return [line for line in self._run_script(script) if line and not line.startswith(">>")]

    def _run_script(self, script: str) -> list[str]:
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
            capture_output=True,
            text=True,
            creationflags=creation_flags(),
        )
        if proc.returncode != 0:
            raise RuntimeError(proc.stderr.strip() or proc.stdout.strip() or "Sandboxie command failed")
        return [line.strip() for line in proc.stdout.splitlines() if line.strip()]

# Services: Node

import subprocess
from pathlib import Path



class NodeService:
    def __init__(self, sandboxie: SandboxieService, admin_password: str) -> None:
        self.sandboxie = sandboxie
        self.admin_password = admin_password

    def start_node(self, user_name: str, box_name: str, app_exe: str) -> list[str]:
        app_path = Path(app_exe)
        if not app_path.exists():
            raise RuntimeError(f"EarnApp not found: {app_exe}")

        app_dir = str(app_path.parent)
        script = r'''
$ErrorActionPreference = "Stop"
$UserName = "__USER__"
$Password = "__PASSWORD__"
$StartExe = "__START__"
$SandManExe = "__SANDMAN__"
$AppExe = "__APP__"
$AppDir = "__APPDIR__"
$BaseDir = "__BASEDIR__"
$BoxName = "__BOX__"

Set-Service -Name "seclogon" -StartupType Manual -ErrorAction SilentlyContinue
Start-Service -Name "seclogon" -ErrorAction SilentlyContinue

if (-not (Test-Path $AppExe)) {
    throw "EarnApp not found: $AppExe"
}

$start = Start-Process -FilePath $StartExe -ArgumentList @("/box:$BoxName", $AppExe) -WorkingDirectory $AppDir -WindowStyle Normal -PassThru
Start-Sleep -Seconds 2

$secpasswd = ConvertTo-SecureString $Password -AsPlainText -Force
$cred = New-Object System.Management.Automation.PSCredential ($UserName, $secpasswd)
$sand = Start-Process -FilePath $SandManExe -Credential $cred -LoadUserProfile -WorkingDirectory $BaseDir -WindowStyle Normal -PassThru

Write-Host ">> LaunchCmd    = `"$StartExe`" /box:$BoxName `"$AppExe`""
Write-Host ">> StartPid     = $($start.Id)"
Write-Host ">> SandManPid   = $($sand.Id)"
'''
        script = (
            script.replace("__USER__", user_name)
            .replace("__PASSWORD__", self.admin_password)
            .replace("__START__", self.sandboxie.start_exe)
            .replace("__SANDMAN__", self.sandboxie.sandman_exe)
            .replace("__APP__", app_exe)
            .replace("__APPDIR__", app_dir)
            .replace("__BASEDIR__", self.sandboxie.base_dir)
            .replace("__BOX__", box_name)
        )
        return self._run_script(script)

    def extract_runtime_pids(self, logs: list[str]) -> tuple[int | None, int | None]:
        return self._extract_pid(logs, "StartPid"), self._extract_pid(logs, "SandManPid")

    def stop_node(self, user_name: str, box_name: str, app_dir: str) -> list[str]:
        script = r'''
$ErrorActionPreference = "Stop"
$StartExe = "__START__"
$SandManExe = "__SANDMAN__"
$BoxName = "__BOX__"
$UserName = "__USER__"
$AppDir = "__APPDIR__"

Get-Process -ErrorAction SilentlyContinue | Where-Object {
    try { $procPath = $_.Path } catch { $procPath = $null }
    $procPath -and ($procPath -like "$AppDir*")
} | Stop-Process -Force -ErrorAction SilentlyContinue

Start-Sleep -Milliseconds 500
Start-Process -FilePath $StartExe -ArgumentList "/box:$BoxName /terminate" -Wait -WindowStyle Hidden -ErrorAction SilentlyContinue

$sandProcs = Get-CimInstance Win32_Process -Filter "Name='SandMan.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.ExecutablePath -and ($_.ExecutablePath -ieq $SandManExe) }

foreach ($proc in $sandProcs) {
    try {
        $ownerResult = Invoke-CimMethod -InputObject $proc -MethodName GetOwner -ErrorAction Stop
        if ($ownerResult -and $ownerResult.ReturnValue -eq 0) {
            $ownerText = "$($ownerResult.Domain)\$($ownerResult.User)"
            if ($ownerText -like "*\$UserName") {
                Stop-Process -Id $proc.ProcessId -Force -ErrorAction SilentlyContinue
                Write-Host ">> Closed SandMan for $ownerText"
            }
        }
    }
    catch {
    }
}

Write-Host ">> Terminated box: $BoxName"
'''
        script = (
            script.replace("__START__", self.sandboxie.start_exe)
            .replace("__SANDMAN__", self.sandboxie.sandman_exe)
            .replace("__BOX__", box_name)
            .replace("__USER__", user_name)
            .replace("__APPDIR__", app_dir)
        )
        return self._run_script(script)

    def _run_script(self, script: str) -> list[str]:
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
            capture_output=True,
            text=True,
            creationflags=creation_flags(),
        )
        if proc.returncode != 0:
            raise RuntimeError(proc.stderr.strip() or proc.stdout.strip() or "Node action failed")
        return [line.strip() for line in proc.stdout.splitlines() if line.strip()]

    def _extract_pid(self, logs: list[str], label: str) -> int | None:
        prefix = f">> {label}"
        for line in logs:
            if not line.startswith(prefix):
                continue
            if "=" not in line:
                continue
            _, value = line.split("=", 1)
            value = value.strip()
            if not value:
                return None
            try:
                return int(value)
            except ValueError:
                return None
        return None

# Services: User

import subprocess



class UserService:
    def ensure_users(self, prefix: str, count: int, password: str) -> list[str]:
        script = r'''
$ErrorActionPreference = "Stop"
$Prefix = "__PREFIX__"
$Count = __COUNT__
$Password = ConvertTo-SecureString "__PASSWORD__" -AsPlainText -Force

function Ensure-LocalAdminUser([string]$UserName, [securestring]$UserPass) {
    $user = Get-LocalUser -Name $UserName -ErrorAction SilentlyContinue
    if (-not $user) {
        New-LocalUser -Name $UserName -Password $UserPass -FullName "EarnApp Node $UserName" -PasswordNeverExpires | Out-Null
        Write-Host ">> Created local user: $UserName"
    }
    else {
        Write-Host ">> Local user exists: $UserName"
    }

    Add-LocalGroupMember -Group "Administrators" -Member $UserName -ErrorAction SilentlyContinue | Out-Null

    $ProfilePath = "C:\Users\$UserName"
    if (-not (Test-Path $ProfilePath)) {
        Write-Host ">> Creating Windows profile: $ProfilePath"
        $Process = New-Object System.Diagnostics.Process
        $Process.StartInfo.FileName = "cmd.exe"
        $Process.StartInfo.Arguments = "/c exit"
        $Process.StartInfo.UserName = $UserName
        $Process.StartInfo.Password = $UserPass
        $Process.StartInfo.UseShellExecute = $false
        $Process.StartInfo.LoadUserProfile = $true
        $Process.StartInfo.CreateNoWindow = $true
        $Process.Start() | Out-Null
        $Process.WaitForExit()
        Start-Sleep -Seconds 2
    }
    else {
        Write-Host ">> Profile exists: $ProfilePath"
    }
}

for ($i = 1; $i -le $Count; $i++) {
    Ensure-LocalAdminUser -UserName ($Prefix + $i) -UserPass $Password
}
'''
        script = script.replace("__PREFIX__", prefix).replace("__COUNT__", str(count)).replace("__PASSWORD__", password)
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
            capture_output=True,
            text=True,
            creationflags=creation_flags(),
        )
        if proc.returncode != 0:
            raise RuntimeError(proc.stderr.strip() or proc.stdout.strip() or "User creation failed")
        return [line.strip() for line in proc.stdout.splitlines() if line.strip().startswith(">>")]

# Services: Verify

import subprocess



class VerifyService:
    def __init__(self, sandboxie: SandboxieService) -> None:
        self.sandboxie = sandboxie

    def verify_node(self, user_name: str, box_name: str, app_exe: str) -> tuple[bool, list[str]]:
        script = r'''
$ErrorActionPreference = "Stop"
$StartExe = "__START__"
$SandManExe = "__SANDMAN__"
$SbieIniExe = "__SBIEINI__"
$BoxName = "__BOX__"
$UserName = "__USER__"
$AppExe = "__APP__"
$BoxPath = "C:\Sandbox\$UserName\$BoxName"

function Get-OwnerText([object]$Proc) {
    $ownerText = "(unknown)"
    if ($Proc) {
        try {
            $ownerResult = Invoke-CimMethod -InputObject $Proc -MethodName GetOwner -ErrorAction Stop
            if ($ownerResult -and $ownerResult.ReturnValue -eq 0) {
                $ownerText = "$($ownerResult.Domain)\$($ownerResult.User)"
            }
        } catch {}
    }
    return $ownerText
}

$enabledBoxList = @(
    & $SbieIniExe queryex /boxes * |
    ForEach-Object { $_.ToString().Trim() } |
    Where-Object { $_ }
)
$boxExists = $enabledBoxList -contains $BoxName
Write-Host ">> BoxExists    = $boxExists"

$earnProc = Get-CimInstance Win32_Process -Filter "Name='earnapp.exe'" -ErrorAction SilentlyContinue |
    Where-Object {
        ($_.ExecutablePath -and ($_.ExecutablePath -ieq $AppExe)) -or
        ($_.CommandLine -and ($_.CommandLine -like "*$AppExe*"))
    } |
    Select-Object -First 1

$earnRunning = $null -ne $earnProc
Write-Host ">> EarnRunning  = $earnRunning"

if ($earnProc) {
    Write-Host ">> VerifyEarnPid   = $($earnProc.ProcessId)"
    Write-Host ">> VerifyEarnPath  = $($earnProc.ExecutablePath)"
    if ($earnProc.CommandLine) {
        Write-Host ">> VerifyEarnCmd   = $($earnProc.CommandLine)"
    }
    Write-Host ">> VerifyOwnerWmi  = $(Get-OwnerText $earnProc)"
    $psProc = Get-Process -Id $earnProc.ProcessId -IncludeUserName -ErrorAction SilentlyContinue
    if ($psProc -and $psProc.UserName) {
        Write-Host ">> VerifyOwnerPs   = $($psProc.UserName)"
    }
}

$boxPathExists = Test-Path $BoxPath
$boxHasData = $false
if ($boxPathExists) {
    $items = @(Get-ChildItem -Path $BoxPath -Force -ErrorAction SilentlyContinue)
    $boxHasData = $items.Count -gt 0
    Write-Host ">> BoxPathExists = $boxPathExists"
    Write-Host ">> BoxHasData    = $boxHasData"
    foreach ($item in ($items | Select-Object -First 5)) {
        Write-Host ">> BoxItem       = $($item.FullName)"
    }
}
else {
    Write-Host ">> BoxPathExists = False"
    Write-Host ">> BoxHasData    = False"
}

$rawListPids = @(
    & $StartExe /box:$BoxName /listpids |
    ForEach-Object { $_.ToString().Trim() } |
    Where-Object { $_ }
)

if ($rawListPids.Count -gt 0) {
    Write-Host ">> ListPidsCount = $($rawListPids[0])"
    for ($i = 1; $i -lt $rawListPids.Count; $i++) {
        Write-Host ">> ListPid       = $($rawListPids[$i])"
    }
}
else {
    Write-Host ">> ListPidsCount = 0"
}

$sandProcs = Get-CimInstance Win32_Process -Filter "Name='SandMan.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.ExecutablePath -and ($_.ExecutablePath -ieq $SandManExe) }
$sandForUser = $false
foreach ($proc in $sandProcs) {
    $owner = Get-OwnerText $proc
    Write-Host ">> SandManPid      = $($proc.ProcessId)"
    Write-Host ">> SandManOwnerWmi = $owner"
    $psProc = Get-Process -Id $proc.ProcessId -IncludeUserName -ErrorAction SilentlyContinue
    if ($psProc -and $psProc.UserName) {
        Write-Host ">> SandManOwnerPs  = $($psProc.UserName)"
        if ($psProc.UserName -like "*\$UserName") {
            $sandForUser = $true
        }
    }
    if ($owner -like "*\$UserName") {
        $sandForUser = $true
    }
}

$verifyOk = $boxExists -and $earnRunning -and ($boxPathExists -or $boxHasData)
Write-Host ">> VerifySandManForUser = $sandForUser"
Write-Host ">> VerifyOk             = $verifyOk"

if (-not $verifyOk) {
    exit 3
}
'''
        script = (
            script.replace("__START__", self.sandboxie.start_exe)
            .replace("__SANDMAN__", self.sandboxie.sandman_exe)
            .replace("__SBIEINI__", self.sandboxie.sbieini_exe)
            .replace("__BOX__", box_name)
            .replace("__USER__", user_name)
            .replace("__APP__", app_exe)
        )
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
            capture_output=True,
            text=True,
            creationflags=creation_flags(),
        )
        logs = [line.strip() for line in proc.stdout.splitlines() if line.strip()]
        return proc.returncode == 0, logs

# Services: EarnApp

from pathlib import Path


class EarnAppService:
    def __init__(self, root_dir: str) -> None:
        self.root_dir = Path(root_dir)

    def node_dir(self, node_number: int) -> Path:
        return self.root_dir / f"EarnApp{node_number}"

    def app_path(self, node_number: int) -> Path:
        return self.node_dir(node_number) / "EarnApp.exe"

# Services: Window Process

import ctypes
import json
import os
import subprocess
import time
from dataclasses import dataclass
from ctypes import wintypes



@dataclass(slots=True)
class ProcessRecord:
    pid: int
    name: str
    path: str = ""
    owner: str = ""
    command_line: str = ""


class WindowProcessService:
    SW_HIDE = 0
    SW_SHOW = 5
    SW_RESTORE = 9
    WM_CLOSE = 0x0010

    def __init__(self) -> None:
        self.user32 = ctypes.WinDLL("user32", use_last_error=True)

    def find_earnapp_process(self, earnapp_path: str) -> ProcessRecord | None:
        normalized_path = self._normalize_path(earnapp_path)
        for record in self._query_processes("EarnApp.exe"):
            if self._normalize_path(record.path) == normalized_path:
                return record
            if record.command_line and normalized_path in record.command_line.lower():
                return record
        return None

    def find_sandman_process(self, user_name: str, sandman_exe: str) -> ProcessRecord | None:
        normalized_path = self._normalize_path(sandman_exe)
        owner_suffix = f"\\{user_name}".lower()
        for record in self._query_processes("SandMan.exe"):
            owner = record.owner.lower()
            if self._normalize_path(record.path) == normalized_path and owner.endswith(owner_suffix):
                return record
        return None

    def hide_process_windows(self, pid: int) -> int:
        return self._show_window_for_pid(pid, self.SW_HIDE)

    def show_process_windows(self, pid: int) -> int:
        count = 0
        for hwnd in self._window_handles_for_pid(pid):
            self.user32.ShowWindow(hwnd, self.SW_RESTORE)
            self.user32.ShowWindow(hwnd, self.SW_SHOW)
            count += 1
        return count

    def close_process(self, pid: int) -> str:
        if pid <= 0:
            return "No PID to close"
        hwnds = self._window_handles_for_pid(pid)
        for hwnd in hwnds:
            self.user32.PostMessageW(hwnd, self.WM_CLOSE, 0, 0)
        time.sleep(0.4)
        if self._pid_exists(pid):
            subprocess.run(["taskkill", "/PID", str(pid), "/F"], capture_output=True, text=True, creationflags=creation_flags())
        return f"Close signal sent to PID {pid}"

    def list_related_processes(self, earnapp_root: str, sandman_exe: str, start_exe: str) -> list[str]:
        lines: list[str] = []
        earnapp_root_norm = self._normalize_path(earnapp_root)
        sandman_exe_norm = self._normalize_path(sandman_exe)
        start_exe_norm = self._normalize_path(start_exe)

        for process_name in ("EarnApp.exe", "SandMan.exe", "Start.exe"):
            for record in self._query_processes(process_name):
                record_path = self._normalize_path(record.path)
                if process_name == "EarnApp.exe" and earnapp_root_norm not in record_path:
                    continue
                if process_name == "SandMan.exe" and record_path != sandman_exe_norm:
                    continue
                if process_name == "Start.exe" and record_path != start_exe_norm:
                    continue
                lines.append(
                    f"{record.name} pid={record.pid} owner={record.owner or '-'} path={record.path or '-'}"
                )
        return lines

    def _show_window_for_pid(self, pid: int, show_mode: int) -> int:
        count = 0
        for hwnd in self._window_handles_for_pid(pid):
            self.user32.ShowWindow(hwnd, show_mode)
            count += 1
        return count

    def _window_handles_for_pid(self, pid: int) -> list[int]:
        hwnds: list[int] = []
        enum_windows_proc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)

        def callback(hwnd, _lparam):
            process_id = wintypes.DWORD()
            self.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(process_id))
            if process_id.value == pid and self.user32.IsWindow(hwnd):
                hwnds.append(hwnd)
            return True

        self.user32.EnumWindows(enum_windows_proc(callback), 0)
        return hwnds

    def _query_processes(self, process_name: str) -> list[ProcessRecord]:
        script = rf'''
$items = @(
    Get-CimInstance Win32_Process -Filter "Name='{process_name}'" -ErrorAction SilentlyContinue |
    ForEach-Object {{
        $ownerText = ""
        try {{
            $ownerResult = Invoke-CimMethod -InputObject $_ -MethodName GetOwner -ErrorAction Stop
            if ($ownerResult -and $ownerResult.ReturnValue -eq 0) {{
                $ownerText = "$($ownerResult.Domain)\$($ownerResult.User)"
            }}
        }} catch {{
        }}
        [pscustomobject]@{{
            pid = $_.ProcessId
            name = $_.Name
            path = $_.ExecutablePath
            owner = $ownerText
            command_line = $_.CommandLine
        }}
    }}
)
$items | ConvertTo-Json -Compress
'''
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
            capture_output=True,
            text=True,
            creationflags=creation_flags(),
        )
        if proc.returncode != 0:
            return []
        raw = proc.stdout.strip()
        if not raw:
            return []
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            return []
        if isinstance(payload, dict):
            payload = [payload]
        records: list[ProcessRecord] = []
        for item in payload:
            if not isinstance(item, dict):
                continue
            try:
                records.append(
                    ProcessRecord(
                        pid=int(item.get("pid", 0)),
                        name=str(item.get("name", "")),
                        path=str(item.get("path") or ""),
                        owner=str(item.get("owner") or ""),
                        command_line=str(item.get("command_line") or ""),
                    )
                )
            except (TypeError, ValueError):
                continue
        return records

    def _pid_exists(self, pid: int) -> bool:
        proc = subprocess.run(
            ["tasklist", "/FI", f"PID eq {pid}"],
            capture_output=True,
            text=True,
            creationflags=creation_flags(),
        )
        if proc.returncode != 0:
            return False
        return str(pid) in proc.stdout

    def _normalize_path(self, value: str) -> str:
        return os.path.normcase(os.path.normpath(value or ""))

# Services: Proxifier

import shutil
from pathlib import Path



class ProxifierService:
    def __init__(self, profile_dir: str) -> None:
        self.profile_dir = Path(profile_dir)

    def render_profile_xml(self, proxies: list[ProxyEntry], node_count: int, earnapp_root: str) -> str:
        if not proxies:
            raise RuntimeError("Proxy list is empty")
        assignments: list[ProxyAssignment] = []
        for node in range(1, node_count + 1):
            proxy = proxies[(node - 1) % len(proxies)]
            assignments.append(
                ProxyAssignment(
                    node_number=node,
                    user_name=f"Node{node}",
                    proxy=proxy,
                    proxy_name=f"Proxy {node}",
                )
            )
        return self.render_assigned_profile_xml(assignments, earnapp_root)

    def render_assigned_profile_xml(self, assignments: list[ProxyAssignment], earnapp_root: str) -> str:
        proxy_blocks: list[str] = []
        rule_blocks: list[str] = []

        for proxy_id, assignment in enumerate(assignments, start=1):
            proxy = assignment.proxy
            proxy_label = f"{assignment.resolved_proxy_name()} [Node {assignment.node_number}]"
            auth_block = ""
            if proxy.username:
                auth_block = f"""
      <Authentication enabled=\"true\">
        <Username>{proxy.username}</Username>
        <Password>{proxy.password}</Password>
      </Authentication>"""

            proxy_blocks.append(
                f"""    <Proxy id=\"{proxy_id}\">
      <Name>{proxy_label}</Name>
      <Type>{proxy.proxy_type.upper()}</Type>
      <Address>{proxy.host}</Address>
      <Port>{proxy.port}</Port>{auth_block}
    </Proxy>"""
            )

            rule_blocks.append(
                f"""    <Rule enabled=\"true\">
      <Name>EarnApp{assignment.node_number}</Name>
      <Applications>{earnapp_root}\\EarnApp{assignment.node_number}\\EarnApp.exe</Applications>
      <Action type=\"Proxy\">{proxy_label}</Action>
    </Rule>"""
            )

        rule_blocks.append(
            """    <Rule enabled=\"true\">
      <Name>Default Direct</Name>
      <Applications>*</Applications>
      <Action type=\"Direct\" />
    </Rule>"""
        )

        return f"""<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<ProxifierProfile version=\"4.0\">
  <Options>
    <Resolve>
      <AutoModeDetection enabled=\"true\" />
    </Resolve>
  </Options>
  <ProxyList>
{chr(10).join(proxy_blocks)}
  </ProxyList>
  <RuleList>
{chr(10).join(rule_blocks)}
  </RuleList>
</ProxifierProfile>
"""

    def sync_external_profile(self, source_path_or_dir: str, target_name: str = "default.ppx") -> tuple[str, list[str]]:
        source_path = self._resolve_external_profile(source_path_or_dir)
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        target_path = self.profile_dir / target_name
        shutil.copy2(source_path, target_path)

        logs = [
            f"External Proxifier profile: {source_path}",
            f"Active profile written: {target_path}",
        ]
        if source_path.name.lower() != target_name.lower():
            original_copy = self.profile_dir / source_path.name
            shutil.copy2(source_path, original_copy)
            logs.append(f"Original profile mirrored: {original_copy}")
        return str(target_path), logs

    def _resolve_external_profile(self, source_path_or_dir: str) -> Path:
        source = Path(source_path_or_dir)
        if source.is_file():
            if source.suffix.lower() != ".ppx":
                raise RuntimeError(f"Proxifier source must be a .ppx file: {source}")
            return source
        if not source.exists():
            raise RuntimeError(f"Proxifier source path not found: {source}")

        candidates = [path for path in source.glob("*.ppx") if path.is_file()]
        if not candidates:
            raise RuntimeError(f"No .ppx profile found in: {source}")

        for candidate in candidates:
            if candidate.name.lower() == "default.ppx":
                return candidate
        return max(candidates, key=lambda item: item.stat().st_mtime)

    def write_default_profile(self, xml_content: str, file_name: str = "default.ppx") -> str:
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        out_path = self.profile_dir / file_name
        out_path.write_text(xml_content, encoding="utf-8")
        return str(out_path)

# Services: Update

import json
import shutil
import tempfile
import urllib.error
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path



@dataclass(slots=True)
class ReleaseAsset:
    version: str
    download_url: str
    file_name: str


class EarnAppUpdateService:
    def __init__(self, config: GuestToolConfig) -> None:
        self.config = config
        self.earnapp = EarnAppService(config.earnapp_root)

    def is_configured(self) -> tuple[bool, str]:
        if self.config.github_release_api and self.config.github_asset_name:
            return True, ""
        if self.config.github_version_url:
            return True, ""
        return False, "Update source is not configured"

    def sync(self, node_count: int, current_version: str = "") -> tuple[str, list[str]]:
        asset = self._fetch_release_asset()
        logs = [f"Latest version: {asset.version}"]
        if current_version and current_version == asset.version:
            logs.append(f"Already on version {asset.version}; update skipped.")
            return asset.version, logs

        target_dirs = [self.earnapp.node_dir(node) for node in range(1, node_count + 1) if self.earnapp.node_dir(node).exists()]
        if not target_dirs:
            raise RuntimeError(f"No EarnApp node directories found under {self.config.earnapp_root}")

        with tempfile.TemporaryDirectory() as tmp_dir:
            temp_root = Path(tmp_dir)
            asset_path = temp_root / asset.file_name
            self._download_file(asset.download_url, asset_path)
            logs.append(f"Downloaded asset: {asset_path.name}")
            payload_dir = self._prepare_payload_dir(asset_path, temp_root)
            logs.append(f"Prepared payload from: {payload_dir}")

            for target_dir in target_dirs:
                self._mirror_payload_directory(payload_dir, target_dir)
                logs.append(f"Updated payload: {target_dir}")

        return asset.version, logs

    def _fetch_release_asset(self) -> ReleaseAsset:
        if self.config.github_release_api:
            payload = self._fetch_json(self.config.github_release_api)
            assets = payload.get("assets", []) if isinstance(payload, dict) else []
            asset = None
            for item in assets:
                if not isinstance(item, dict):
                    continue
                if item.get("name") == self.config.github_asset_name:
                    asset = item
                    break
            if asset is None:
                raise RuntimeError(f"GitHub asset '{self.config.github_asset_name}' not found")
            version = str(payload.get("tag_name") or payload.get("name") or "unknown")
            download_url = str(asset.get("browser_download_url") or "")
            if not download_url:
                raise RuntimeError("GitHub asset download URL is missing")
            return ReleaseAsset(version=version, download_url=download_url, file_name=str(asset.get("name") or self.config.github_asset_name))

        if self.config.github_version_url:
            payload = self._fetch_json(self.config.github_version_url)
            if not isinstance(payload, dict):
                raise RuntimeError("Version endpoint must return a JSON object")
            version = str(payload.get("version") or payload.get("tag_name") or payload.get("name") or "unknown")
            download_url = str(payload.get("asset_url") or payload.get("download_url") or "")
            if not download_url:
                raise RuntimeError("Version endpoint did not provide an asset URL")
            file_name = str(payload.get("asset_name") or self.config.github_asset_name or Path(download_url).name)
            return ReleaseAsset(version=version, download_url=download_url, file_name=file_name)

        raise RuntimeError("Update source is not configured")

    def _fetch_json(self, url: str):
        request = urllib.request.Request(url, headers={"User-Agent": "Codex-GuestTool/1.0"})
        try:
            with urllib.request.urlopen(request, timeout=20) as response:
                raw = response.read().decode("utf-8")
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Failed to fetch update metadata: {exc}") from exc
        return json.loads(raw)

    def _download_file(self, url: str, destination: Path) -> None:
        request = urllib.request.Request(url, headers={"User-Agent": "Codex-GuestTool/1.0"})
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                destination.write_bytes(response.read())
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Failed to download update asset: {exc}") from exc

    def _prepare_payload_dir(self, asset_path: Path, temp_root: Path) -> Path:
        if asset_path.suffix.lower() == ".zip":
            extract_root = temp_root / "extract"
            extract_root.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(asset_path) as archive:
                archive.extractall(extract_root)
            payload_dir = self._resolve_payload_root(extract_root)
        elif asset_path.suffix.lower() == ".exe":
            payload_dir = temp_root / "payload"
            payload_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(asset_path, payload_dir / "EarnApp.exe")
        else:
            raise RuntimeError(f"Unsupported update asset: {asset_path.name}")

        earnapp_exe = next(payload_dir.rglob("EarnApp.exe"), None)
        if earnapp_exe is None:
            raise RuntimeError("Update payload does not contain EarnApp.exe")
        return earnapp_exe.parent

    def _resolve_payload_root(self, extract_root: Path) -> Path:
        children = list(extract_root.iterdir())
        if len(children) == 1 and children[0].is_dir():
            return children[0]
        return extract_root

    def _mirror_payload_directory(self, payload_dir: Path, target_dir: Path) -> None:
        target_dir.mkdir(parents=True, exist_ok=True)
        backup_dir = target_dir.parent / f".{target_dir.name}.backup"
        if backup_dir.exists():
            shutil.rmtree(backup_dir, ignore_errors=True)
        backup_dir.mkdir(parents=True, exist_ok=True)

        touched_paths: list[Path] = []
        try:
            for item in payload_dir.iterdir():
                destination = target_dir / item.name
                if destination.exists():
                    backup_destination = backup_dir / item.name
                    backup_destination.parent.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(destination), str(backup_destination))
                touched_paths.append(destination)
                if item.is_dir():
                    shutil.copytree(item, destination)
                else:
                    shutil.copy2(item, destination)
        except Exception:
            for destination in reversed(touched_paths):
                if destination.exists():
                    if destination.is_dir():
                        shutil.rmtree(destination, ignore_errors=True)
                    else:
                        destination.unlink(missing_ok=True)
            for backup_item in backup_dir.iterdir():
                destination = target_dir / backup_item.name
                shutil.move(str(backup_item), str(destination))
            raise
        finally:
            shutil.rmtree(backup_dir, ignore_errors=True)

# Runtime Orchestrator

import subprocess
import time
from collections.abc import Callable



LogFn = Callable[[str, str], None]


def parse_node_target(raw: str, max_node: int) -> NodeTarget:
    text = raw.strip()
    if not text:
        raise ValueError("Index is empty")

    if "-" in text:
        if text.count("-") != 1:
            raise ValueError(f"Invalid index format: {raw}")
        start_text, end_text = text.split("-", 1)
        start = int(start_text.strip())
        end = int(end_text.strip())
        if start > end:
            raise ValueError("Index invalid: start > end")
        nodes = list(range(start, end + 1))
        kind = "range"
    else:
        nodes = [int(text)]
        kind = "single"

    for node in nodes:
        if node < 1 or node > max_node:
            raise ValueError(f"Node {node} out of range 1..{max_node}")

    return NodeTarget(raw=text, nodes=nodes, kind=kind)


class RuntimeOrchestrator:
    def __init__(self, config: GuestToolConfig, logger: LogFn | None = None) -> None:
        self.config = config
        self.logger = logger or (lambda _msg, _tag="": None)
        self.sandboxie = SandboxieService(config.sandboxie_root)
        self.earnapp = EarnAppService(config.earnapp_root)
        self.proxifier = ProxifierService(config.proxifier_profile_dir)
        self.node_service = NodeService(self.sandboxie, config.admin_password)
        self.verify_service = VerifyService(self.sandboxie)
        self.user_service = UserService()
        self.window_service = WindowProcessService()

    def sync_proxifier(self) -> str:
        path, logs = self.proxifier.sync_external_profile(self.config.proxifier_sync_source)
        for line in logs:
            self.logger(line, "dim")
        self.logger("External .ppx profile synced to Proxifier.", "ok")
        return path

    def ensure_runtime_ready(self) -> None:
        for line in self.sandboxie.ensure_runtime_ready():
            self.logger(line, "dim")
        for line in self.sandboxie.ensure_core_services():
            self.logger(line, "info" if line.startswith(">> ----") else "dim")
        for line in self.user_service.ensure_users(self.config.user_prefix, self.config.node_count, self.config.admin_password):
            self.logger(line, "info")

    def run_target(
        self,
        target: NodeTarget,
        interval_seconds: float,
        runtime_states: dict[int, NodeRuntimeState],
        auto_hide: bool = False,
        sandman_hide: bool = False,
    ) -> None:
        self.ensure_runtime_ready()
        self.sync_proxifier()

        for position, node_number in enumerate(target.nodes):
            if position > 0 and interval_seconds > 0:
                self.logger(f"Delay {interval_seconds} sec truoc khi chay Node {node_number}...", "dim")
                time.sleep(interval_seconds)
            self.logger(f"> Bat dau chay Node {node_number}...", "head")
            self._start_single_node(node_number, runtime_states)
            if target.kind == "range" and auto_hide:
                self.hide_earnapp(node_number, runtime_states, quiet=False)
            if target.kind == "range" and sandman_hide:
                self.hide_sandman(node_number, runtime_states, quiet=False)

    def verify_nodes(self, nodes: list[int], runtime_states: dict[int, NodeRuntimeState]) -> None:
        for node_number in nodes:
            self.logger(f"> Verify Node {node_number}...", "head")
            self._verify_single_node(node_number, runtime_states)

    def stop_nodes(self, nodes: list[int], runtime_states: dict[int, NodeRuntimeState]) -> None:
        for node_number in nodes:
            self.logger(f"> Stop Node {node_number}...", "head")
            self._stop_single_node(node_number, runtime_states)

    def hide_earnapp(self, node_number: int, runtime_states: dict[int, NodeRuntimeState], quiet: bool = False) -> bool:
        state = self._ensure_runtime_state(node_number, runtime_states)
        record = self.window_service.find_earnapp_process(state.earnapp_path)
        if record is None:
            if not quiet:
                self.logger(f"WARN khong tim thay EarnApp process cho Node {node_number}", "warn")
            return False
        hidden_count = self.window_service.hide_process_windows(record.pid)
        state.start_pid = record.pid
        state.earnapp_hidden = hidden_count > 0
        state.last_action = "hide"
        if not quiet:
            tag = "ok" if hidden_count > 0 else "warn"
            self.logger(f"Hide Node {node_number}: {hidden_count} window(s)", tag)
        return hidden_count > 0

    def show_earnapp(self, node_number: int, runtime_states: dict[int, NodeRuntimeState]) -> bool:
        state = self._ensure_runtime_state(node_number, runtime_states)
        record = self.window_service.find_earnapp_process(state.earnapp_path)
        if record is None:
            self.logger(f"WARN khong tim thay EarnApp process cho Node {node_number}", "warn")
            return False
        shown_count = self.window_service.show_process_windows(record.pid)
        state.start_pid = record.pid
        state.earnapp_hidden = False
        state.last_action = "show"
        tag = "ok" if shown_count > 0 else "warn"
        self.logger(f"Show Node {node_number}: {shown_count} window(s)", tag)
        return shown_count > 0

    def hide_sandman(self, node_number: int, runtime_states: dict[int, NodeRuntimeState], quiet: bool = False) -> bool:
        state = self._ensure_runtime_state(node_number, runtime_states)
        record = self.window_service.find_sandman_process(state.user_name, self.sandboxie.sandman_exe)
        if record is None:
            if not quiet:
                self.logger(f"WARN khong tim thay SandMan process cho {state.user_name}", "warn")
            return False
        hidden_count = self.window_service.hide_process_windows(record.pid)
        state.sandman_pid = record.pid
        state.sandman_hidden = hidden_count > 0
        if not quiet:
            tag = "ok" if hidden_count > 0 else "warn"
            self.logger(f"SandMan Hide Node {node_number}: {hidden_count} window(s)", tag)
        return hidden_count > 0

    def hide_all(self, runtime_states: dict[int, NodeRuntimeState]) -> int:
        hidden_nodes = 0
        for node_number in range(1, self.config.node_count + 1):
            if self.hide_earnapp(node_number, runtime_states, quiet=True):
                hidden_nodes += 1
        self.logger(f"Hide All completed: {hidden_nodes} node(s)", "ok" if hidden_nodes else "warn")
        return hidden_nodes

    def open_process_explorer(self) -> list[str]:
        try:
            subprocess.Popen(list(self.config.task_manager_command), creationflags=creation_flags())
            self.logger("Opened Task Manager.", "ok")
            return []
        except Exception as exc:
            self.logger(f"Task Manager open failed: {exc}", "warn")
            lines = self.window_service.list_related_processes(
                self.config.earnapp_root,
                self.sandboxie.sandman_exe,
                self.sandboxie.start_exe,
            )
            for line in lines:
                self.logger(line, "dim")
            return lines

    def _start_single_node(self, node_number: int, runtime_states: dict[int, NodeRuntimeState]) -> None:
        user_name = f"{self.config.user_prefix}{node_number}"
        box_name = self.sandboxie.box_name(user_name)
        app_path = str(self.earnapp.app_path(node_number))
        if not self.earnapp.app_path(node_number).exists():
            raise RuntimeError(f"EarnApp not found for Node {node_number}: {app_path}")

        for line in self.sandboxie.create_box(user_name, box_name):
            self.logger(line, "dim")
        start_logs = self.node_service.start_node(user_name, box_name, app_path)
        for line in start_logs:
            self.logger(line, "info")

        start_pid, sandman_pid = self.node_service.extract_runtime_pids(start_logs)
        state = NodeRuntimeState(
            node_number=node_number,
            user_name=user_name,
            box_name=box_name,
            earnapp_path=app_path,
            start_pid=start_pid,
            sandman_pid=sandman_pid,
            last_action="run",
        )
        runtime_states[node_number] = state
        self._verify_single_node(node_number, runtime_states)

    def _verify_single_node(self, node_number: int, runtime_states: dict[int, NodeRuntimeState]) -> bool:
        state = self._ensure_runtime_state(node_number, runtime_states)
        ok, logs = self.verify_service.verify_node(state.user_name, state.box_name, state.earnapp_path)
        for line in logs:
            self.logger(line, "dim")
        state.last_verify_ok = ok
        state.last_action = "verify"
        if ok:
            self.logger(f"OK verify Node {node_number} voi box {state.box_name}", "ok")
        else:
            self.logger(f"WARN verify chua pass cho Node {node_number} voi box {state.box_name}", "warn")
        return ok

    def _stop_single_node(self, node_number: int, runtime_states: dict[int, NodeRuntimeState]) -> None:
        state = self._ensure_runtime_state(node_number, runtime_states)
        app_dir = str(self.earnapp.node_dir(node_number))
        for line in self.node_service.stop_node(state.user_name, state.box_name, app_dir):
            self.logger(line, "warn")
        for line in self.sandboxie.delete_box(state.user_name, state.box_name):
            self.logger(line, "dim")
        state.start_pid = None
        state.sandman_pid = None
        state.earnapp_hidden = False
        state.sandman_hidden = False
        state.last_action = "close"
        self.logger(f"OK da stop Node {node_number} voi box {state.box_name}", "ok")

    def _ensure_runtime_state(self, node_number: int, runtime_states: dict[int, NodeRuntimeState]) -> NodeRuntimeState:
        state = runtime_states.get(node_number)
        if state is not None:
            return state
        user_name = f"{self.config.user_prefix}{node_number}"
        state = NodeRuntimeState(
            node_number=node_number,
            user_name=user_name,
            box_name=self.sandboxie.box_name(user_name),
            earnapp_path=str(self.earnapp.app_path(node_number)),
        )
        runtime_states[node_number] = state
        return state

# App

import json
import threading
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import messagebox, ttk



class GuestToolApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.app_config = self._load_config()
        self.session = self._load_session()
        self.runtime_states: dict[int, NodeRuntimeState] = self.session.runtime_states
        self.orchestrator = RuntimeOrchestrator(self.app_config, self.log)
        self.update_service = EarnAppUpdateService(self.app_config)
        self._busy = False
        self._action_buttons: list[ttk.Button] = []

        self.title("Compact Guest Node Panel")
        self.geometry("1180x760")
        self.minsize(980, 620)
        self.configure(bg="#f2f2f2")

        self.status_var = tk.StringVar(value="Ready")
        self.node_index_var = tk.StringVar(value=self.session.node_index or "1")
        self.interval_var = tk.StringVar(value=self.session.interval_seconds or "5")
        self.auto_hide_var = tk.BooleanVar(value=self.session.auto_hide)
        self.sandman_hide_var = tk.BooleanVar(value=self.session.sandman_hide)
        self.monitor_var = tk.BooleanVar(value=False)
        self.logs_var = tk.BooleanVar(value=False)
        self.topmost_var = tk.BooleanVar(value=False)
        self.follow_sync_var = tk.BooleanVar(value=False)

        self.log_text = None
        self.run_button: ttk.Button | None = None
        self.stop_button: ttk.Button | None = None
        self.close_button: ttk.Button | None = None
        self.back_button: ttk.Button | None = None
        self.next_button: ttk.Button | None = None
        self.show_button: ttk.Button | None = None
        self.hide_button: ttk.Button | None = None
        self.hide_all_button: ttk.Button | None = None
        self.close_all_button: ttk.Button | None = None
        self.proxifier_sync_button: ttk.Button | None = None
        self.update_sync_button: ttk.Button | None = None
        self.process_explorer_button: ttk.Button | None = None

        self._apply_styles()
        self._build_ui()
        self._bind_state()
        self._refresh_control_states()
        self._log_startup_summary()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _load_config(self) -> GuestToolConfig:
        config = GuestToolConfig()
        seed_path = Path.cwd() / "guest_seed.json"
        if not seed_path.exists():
            return config
        try:
            payload = json.loads(seed_path.read_text(encoding="utf-8"))
        except Exception:
            return config
        return config.with_seed_payload(payload)

    def _load_session(self) -> GuestPanelSession:
        session_path = Path(self.app_config.session_state_path)
        if not session_path.exists():
            return GuestPanelSession()
        try:
            payload = json.loads(session_path.read_text(encoding="utf-8"))
            return GuestPanelSession.from_dict(payload)
        except Exception:
            return GuestPanelSession()

    def _persist_session(self) -> None:
        self.session.node_index = self.node_index_var.get().strip() or "1"
        self.session.interval_seconds = self.interval_var.get().strip() or "0"
        self.session.auto_hide = self.auto_hide_var.get()
        self.session.sandman_hide = self.sandman_hide_var.get()
        self.session.runtime_states = self.runtime_states

        session_path = Path(self.app_config.session_state_path)
        session_path.parent.mkdir(parents=True, exist_ok=True)
        session_path.write_text(json.dumps(self.session.to_dict(), indent=2), encoding="utf-8")

    def _apply_styles(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(".", font=("Segoe UI", 10), background="#f2f2f2", foreground="#202020")
        style.configure("TFrame", background="#f2f2f2")
        style.configure("Header.TFrame", background="#fafafa")
        style.configure("Header.TLabel", background="#fafafa", foreground="#202020", font=("Segoe UI Semibold", 11))
        style.configure("Status.TLabel", background="#fafafa", foreground="#0b5fad", font=("Segoe UI", 10, "bold"))
        style.configure("Card.TLabelframe", background="#f2f2f2", foreground="#202020")
        style.configure("Card.TLabelframe.Label", background="#f2f2f2", foreground="#202020", font=("Segoe UI", 10, "bold"))
        style.configure("TButton", padding=(8, 6), background="#ececec", foreground="#202020")
        style.map("TButton", background=[("active", "#dcdcdc")])
        style.configure("Accent.TButton", background="#dfefff", foreground="#0a3b72")
        style.configure("Warn.TButton", background="#fff0d8", foreground="#7a4b00")
        style.configure("Danger.TButton", background="#ffe0e5", foreground="#8b1320")
        style.configure("Success.TButton", background="#e1f6df", foreground="#1b5e20")
        style.configure("TEntry", fieldbackground="#ffffff", foreground="#202020")
        style.configure("TCheckbutton", background="#f2f2f2", foreground="#202020")
        style.map("TCheckbutton", background=[("active", "#f2f2f2")])

    def _build_ui(self) -> None:
        header = ttk.Frame(self, style="Header.TFrame")
        header.pack(fill="x", padx=10, pady=(10, 6))

        title = f"Compact Guest Node Panel | User: {self.app_config.user_prefix} | Nodes: 1-{self.app_config.node_count}"
        ttk.Label(header, text=title, style="Header.TLabel").pack(side="left", padx=10, pady=8)
        ttk.Label(header, textvariable=self.status_var, style="Status.TLabel").pack(side="right", padx=10)

        controls = ttk.Frame(self)
        controls.pack(fill="x", padx=10, pady=(0, 8))
        controls.columnconfigure(0, weight=0)
        controls.columnconfigure(1, weight=1)
        controls.columnconfigure(2, weight=0)

        input_frame = ttk.LabelFrame(controls, text="Runtime", style="Card.TLabelframe")
        input_frame.grid(row=0, column=0, sticky="nw", padx=(0, 12))
        ttk.Label(input_frame, text="Index", width=15).grid(row=0, column=0, sticky="w", padx=10, pady=(10, 4))
        ttk.Entry(input_frame, textvariable=self.node_index_var, width=14, justify="center").grid(row=1, column=0, sticky="ew", padx=10, pady=(0, 8))
        ttk.Label(input_frame, text="Interval / Seconds", width=15).grid(row=0, column=1, sticky="w", padx=10, pady=(10, 4))
        ttk.Entry(input_frame, textvariable=self.interval_var, width=14, justify="center").grid(row=1, column=1, sticky="ew", padx=10, pady=(0, 8))

        button_frame = ttk.Frame(controls)
        button_frame.grid(row=0, column=1, sticky="nsew")
        for column in range(4):
            button_frame.columnconfigure(column, weight=1)

        self.run_button = self._grid_button(button_frame, "Run", self._run_index, 0, 0, "Accent.TButton")
        self.stop_button = self._grid_button(button_frame, "Stop", self._stop_target, 0, 1, "Warn.TButton")
        self.close_button = self._grid_button(button_frame, "Close", self._close_single, 0, 2, "TButton")
        self.proxifier_sync_button = self._grid_button(button_frame, "Proxifier Sync", self._proxifier_sync, 0, 3, "TButton")

        self.back_button = self._grid_button(button_frame, "Back", self._step_index_back, 1, 0, "TButton")
        self.next_button = self._grid_button(button_frame, "Next", self._step_index_next, 1, 1, "TButton")
        self.close_all_button = self._grid_button(button_frame, "Close All", self._close_all, 1, 2, "Danger.TButton")
        self.update_sync_button = self._grid_button(button_frame, "Update Sync", self._update_sync, 1, 3, "TButton")

        self.show_button = self._grid_button(button_frame, "Show", self._show_single, 2, 0, "TButton")
        self.hide_button = self._grid_button(button_frame, "Hide", self._hide_single, 2, 1, "TButton")
        self.hide_all_button = self._grid_button(button_frame, "Hide All", self._hide_all, 2, 2, "TButton")
        self.process_explorer_button = self._grid_button(button_frame, "Process Explorer", self._process_explorer, 2, 3, "TButton")

        option_frame = ttk.LabelFrame(controls, text="Options", style="Card.TLabelframe")
        option_frame.grid(row=0, column=2, sticky="ne")

        self._make_check(option_frame, "Monitor", self.monitor_var, 0, 0, enabled=False)
        self._make_check(option_frame, "Logs", self.logs_var, 0, 1, enabled=False)
        self._make_check(option_frame, "Auto Hide", self.auto_hide_var, 1, 0, enabled=True)
        self._make_check(option_frame, "Top Most", self.topmost_var, 1, 1, enabled=False)
        self._make_check(option_frame, "SandMan Hide", self.sandman_hide_var, 2, 0, enabled=True)
        self._make_check(option_frame, "Follow Sync", self.follow_sync_var, 2, 1, enabled=False)

        log_frame = ttk.Frame(self)
        log_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.log_text = build_log_widget(log_frame)
        self.log_text.tag_configure("ok", foreground=OK)
        self.log_text.tag_configure("err", foreground=ERR)
        self.log_text.tag_configure("warn", foreground=WARN)
        self.log_text.tag_configure("info", foreground=INFO)
        self.log_text.tag_configure("head", foreground=ACC)
        self.log_text.tag_configure("dim", foreground=DIM)

    def _grid_button(self, parent: ttk.Frame, text: str, command, row: int, column: int, style: str) -> ttk.Button:
        button = ttk.Button(parent, text=text, command=command, style=style, width=18)
        button.grid(row=row, column=column, padx=6, pady=6, sticky="ew")
        self._action_buttons.append(button)
        return button

    def _make_check(self, parent: ttk.LabelFrame, text: str, variable: tk.BooleanVar, row: int, column: int, enabled: bool) -> None:
        check = ttk.Checkbutton(parent, text=text, variable=variable)
        check.grid(row=row, column=column, sticky="w", padx=10, pady=5)
        if not enabled:
            check.state(["disabled"])

    def _bind_state(self) -> None:
        self.node_index_var.trace_add("write", self._on_input_changed)
        self.interval_var.trace_add("write", self._on_input_changed)
        self.auto_hide_var.trace_add("write", self._on_input_changed)
        self.sandman_hide_var.trace_add("write", self._on_input_changed)

    def _on_input_changed(self, *_args) -> None:
        self._refresh_control_states()
        self._persist_session()

    def _log_startup_summary(self) -> None:
        self.log(f"Proxifier sync source: {self.app_config.proxifier_sync_source}", "dim")
        self.log(f"Proxifier profile dir: {self.app_config.proxifier_profile_dir}", "dim")
        self.log(f"EarnApp root: {self.app_config.earnapp_root}", "dim")
        update_ok, update_reason = self.update_service.is_configured()
        if update_ok:
            self.log("Update Sync is configured.", "dim")
        else:
            self.log(f"Update Sync disabled: {update_reason}", "warn")

    def log(self, msg: str, tag: str = "") -> None:
        self.after(0, lambda: self._append_log(msg, tag))

    def _append_log(self, msg: str, tag: str) -> None:
        if not self.log_text:
            return
        self.log_text.insert("end", msg + "\n", tag)
        self.log_text.see("end")
        self.update_idletasks()

    def _set_status(self, text: str) -> None:
        self.after(0, lambda: self.status_var.set(text))

    def _set_busy(self, busy: bool) -> None:
        self._busy = busy
        self.after(0, self._refresh_control_states)

    def _refresh_control_states(self) -> None:
        target = self._safe_parse_target()
        is_single = target is not None and target.kind == "single"
        at_first = is_single and target.single_node == 1
        at_last = is_single and target.single_node == self.app_config.node_count

        self._set_button_state(self.run_button, not self._busy)
        self._set_button_state(self.stop_button, target is not None and not self._busy)
        self._set_button_state(self.close_button, is_single and not self._busy)
        self._set_button_state(self.back_button, is_single and not at_first and not self._busy)
        self._set_button_state(self.next_button, is_single and not at_last and not self._busy)
        self._set_button_state(self.show_button, is_single and not self._busy)
        self._set_button_state(self.hide_button, is_single and not self._busy)
        self._set_button_state(self.hide_all_button, not self._busy)
        self._set_button_state(self.close_all_button, not self._busy)
        self._set_button_state(self.proxifier_sync_button, not self._busy)
        self._set_button_state(self.process_explorer_button, not self._busy)

        update_ok, _reason = self.update_service.is_configured()
        self._set_button_state(self.update_sync_button, update_ok and not self._busy)

    def _set_button_state(self, button: ttk.Button | None, enabled: bool) -> None:
        if button is None:
            return
        button.state(["!disabled"] if enabled else ["disabled"])

    def _safe_parse_target(self) -> NodeTarget | None:
        try:
            return parse_node_target(self.node_index_var.get(), self.app_config.node_count)
        except Exception:
            return None

    def _parse_target_or_warn(self) -> NodeTarget | None:
        try:
            return parse_node_target(self.node_index_var.get(), self.app_config.node_count)
        except Exception as exc:
            messagebox.showwarning("Invalid index", str(exc))
            return None

    def _parse_interval_or_warn(self) -> float | None:
        text = self.interval_var.get().strip() or "0"
        try:
            value = float(text)
        except ValueError:
            messagebox.showwarning("Invalid interval", f"Interval invalid: {text}")
            return None
        if value < 0:
            messagebox.showwarning("Invalid interval", "Interval must be >= 0")
            return None
        return value

    def _run_worker(self, status_text: str, worker) -> None:
        if self._busy:
            return

        def runner() -> None:
            self._set_busy(True)
            self._set_status(status_text)
            try:
                worker()
            except Exception as exc:
                self.log(f"ERROR: {exc}", "err")
            finally:
                self.after(0, self._persist_session)
                self._set_status("Ready")
                self._set_busy(False)

        threading.Thread(target=runner, daemon=True).start()

    def _run_index(self) -> None:
        target = self._parse_target_or_warn()
        if target is None:
            return
        interval_seconds = self._parse_interval_or_warn()
        if interval_seconds is None:
            return
        auto_hide = self.auto_hide_var.get()
        sandman_hide = self.sandman_hide_var.get()
        self._run_worker(
            f"Running {target.raw}...",
            lambda: self.orchestrator.run_target(
                target,
                interval_seconds,
                self.runtime_states,
                auto_hide=auto_hide,
                sandman_hide=sandman_hide,
            ),
        )

    def _stop_target(self) -> None:
        target = self._parse_target_or_warn()
        if target is None:
            return
        self._run_worker(f"Stopping {target.raw}...", lambda: self.orchestrator.stop_nodes(target.nodes, self.runtime_states))

    def _close_single(self) -> None:
        target = self._parse_target_or_warn()
        if target is None:
            return
        if target.kind != "single":
            messagebox.showwarning("Single node only", "Close chi ap dung cho 1 node.")
            return
        self._run_worker(f"Closing node {target.single_node}...", lambda: self.orchestrator.stop_nodes([target.single_node], self.runtime_states))

    def _close_all(self) -> None:
        nodes = list(range(1, self.app_config.node_count + 1))
        self._run_worker("Closing all nodes...", lambda: self.orchestrator.stop_nodes(nodes, self.runtime_states))

    def _hide_single(self) -> None:
        target = self._parse_target_or_warn()
        if target is None:
            return
        if target.kind != "single":
            messagebox.showwarning("Single node only", "Hide chi ap dung cho 1 node.")
            return
        self._run_worker(f"Hiding node {target.single_node}...", lambda: self.orchestrator.hide_earnapp(target.single_node, self.runtime_states))

    def _show_single(self) -> None:
        target = self._parse_target_or_warn()
        if target is None:
            return
        if target.kind != "single":
            messagebox.showwarning("Single node only", "Show chi ap dung cho 1 node.")
            return
        self._run_worker(f"Showing node {target.single_node}...", lambda: self.orchestrator.show_earnapp(target.single_node, self.runtime_states))

    def _hide_all(self) -> None:
        self._run_worker("Hiding all nodes...", lambda: self.orchestrator.hide_all(self.runtime_states))

    def _proxifier_sync(self) -> None:
        def worker() -> None:
            _path = self.orchestrator.sync_proxifier()
            self.session.last_proxy_sync = datetime.now().isoformat(timespec="seconds")
            self.log(f"Last proxy sync: {self.session.last_proxy_sync}", "dim")

        self._run_worker("Syncing Proxifier...", worker)

    def _update_sync(self) -> None:
        update_ok, update_reason = self.update_service.is_configured()
        if not update_ok:
            messagebox.showwarning("Update disabled", update_reason)
            return

        def worker() -> None:
            version, logs = self.update_service.sync(self.app_config.node_count, self.session.last_update_version)
            for line in logs:
                self.log(line, "info")
            self.session.last_update_version = version
            self.session.last_update_sync = datetime.now().isoformat(timespec="seconds")
            self.log(f"Last update sync: {self.session.last_update_sync}", "ok")

        self._run_worker("Updating EarnApp payload...", worker)

    def _process_explorer(self) -> None:
        self._run_worker("Opening process explorer...", self.orchestrator.open_process_explorer)

    def _step_index_back(self) -> None:
        target = self._parse_target_or_warn()
        if target is None or target.kind != "single":
            return
        next_node = max(1, target.single_node - 1)
        self.node_index_var.set(str(next_node))

    def _step_index_next(self) -> None:
        target = self._parse_target_or_warn()
        if target is None or target.kind != "single":
            return
        next_node = min(self.app_config.node_count, target.single_node + 1)
        self.node_index_var.set(str(next_node))

    def _on_close(self) -> None:
        self._persist_session()
        self.destroy()


def main() -> None:
    app = GuestToolApp()
    app.mainloop()


if __name__ == "__main__":
    main()

